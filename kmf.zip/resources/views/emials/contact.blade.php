<h3>you have a new contact via the contact form</h3>

<div>
	{{ $bodyMessage }}
</div>

<p>Sent via {{ $email }}</p>