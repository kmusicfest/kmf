<!DOCTYPE html>
<html lang="en">
     <?php echo $__env->make('partials.meta', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

     <?php echo $__env->make('partials.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <body>

      <!-- Navigation -->
     <?php echo $__env->make('partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

      <!-- Page Header -->
     <?php echo $__env->make('partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <!-- Main Content -->
        <div class="container">
     <?php echo $__env->yieldContent('content'); ?>
        </div>

          

      <!-- Footer -->
      <?php echo $__env->make('partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

      <!-- Bootstrap core JavaScript -->
      <?php echo $__env->make('partials.javascript', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  </body>

</html>
