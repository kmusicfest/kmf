<?php $__env->startSection('content'); ?>

<div class="row">
        <div class="col-lg-8 col-md-10 mx-auto">
          <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <?php echo $__env->make('partials.Post', ['post' => $post], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php echo e($posts->links()); ?>

          
  </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>