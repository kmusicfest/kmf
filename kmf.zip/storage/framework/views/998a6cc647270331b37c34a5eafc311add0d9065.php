<div class="post-preview">
      <a href="/post/<?php echo e($post->slug); ?>">
        <h2 class="post-title">
          <?php echo e($post ->title); ?>

        </h2>
        <h3 class="post-subtitle">
          <?php echo e($post ->excerpt); ?>

        </h3>
       </a>
    <p class="post-meta">Posted by
      <a href="#"><?php echo e($post->author->name); ?></a>
        on <?php echo e($post->created_at->format('M d,Y')); ?></p>
</div>
<hr>